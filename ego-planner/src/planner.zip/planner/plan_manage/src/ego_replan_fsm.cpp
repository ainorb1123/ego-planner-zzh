
#include <plan_manage/ego_replan_fsm.h>
#include <boost/bind/bind.hpp>

#define PI 3.1415926
#define yaw_error_max 25.0/180*PI

namespace ego_planner
{
  void EGOReplanFSM::dynamicObstacleCallback(const nav_msgs::OdometryConstPtr& msg, std::string name)
  {
    Eigen::Vector3d pos(msg->pose.pose.position.x, msg->pose.pose.position.y, msg->pose.pose.position.z);
    Eigen::Vector3d vel(msg->twist.twist.linear.x, msg->twist.twist.linear.y, msg->twist.twist.linear.z);

    planner_manager_->updateDynamicObstacle(name, pos, vel, msg->header.stamp);
    ROS_INFO_THROTTLE(1.0, "%s: frame=%s pos=(%.2f, %.2f) vel=(%.2f, %.2f)",
                      name.c_str(), msg->header.frame_id.c_str(), pos.x(), pos.y(), vel.x(), vel.y());
  }

  void EGOReplanFSM::init(ros::NodeHandle &nh)
  {
    current_wp_ = 0;
    exec_state_ = FSM_EXEC_STATE::INIT;
    have_target_ = false;
    have_odom_ = false;

    // 订阅障碍物（他船）位置和速度信息
    obs_overtake_sub_ = nh.subscribe<nav_msgs::Odometry>(
        "/obs_overtake/odom", 10,
        boost::bind(&EGOReplanFSM::dynamicObstacleCallback, this, boost::placeholders::_1, std::string("obs_overtake")));
    obs_headon_sub_ = nh.subscribe<nav_msgs::Odometry>(
        "/obs_headon/odom", 10,
        boost::bind(&EGOReplanFSM::dynamicObstacleCallback, this, boost::placeholders::_1, std::string("obs_headon")));
    obs_port_cross_sub_ = nh.subscribe<nav_msgs::Odometry>(
        "/obs_port_cross/odom", 10,
        boost::bind(&EGOReplanFSM::dynamicObstacleCallback, this, boost::placeholders::_1, std::string("obs_port_cross")));
    obs_stbd_cross_sub_ = nh.subscribe<nav_msgs::Odometry>(
        "/obs_stbd_cross/odom", 10,
        boost::bind(&EGOReplanFSM::dynamicObstacleCallback, this, boost::placeholders::_1, std::string("obs_stbd_cross")));

    /* fsm param  */
    nh.param("fsm/flight_type", target_type_, -1);
    nh.param("fsm/thresh_replan", replan_thresh_, -1.0);
    nh.param("fsm/thresh_no_replan", no_replan_thresh_, -1.0);
    nh.param("fsm/planning_horizon", planning_horizen_, -1.0);
    nh.param("fsm/planning_horizen_time", planning_horizen_time_, -1.0);
    nh.param("fsm/emergency_time_", emergency_time_, 1.0);
    nh.param("fsm/w_adjust_", w_adjust, 1.0);

    nh.param("fsm/waypoint_num", waypoint_num_, -1);
    for (int i = 0; i < waypoint_num_; i++)
    {
      nh.param("fsm/waypoint" + to_string(i) + "_x", waypoints_[i][0], -1.0);
      nh.param("fsm/waypoint" + to_string(i) + "_y", waypoints_[i][1], -1.0);
      nh.param("fsm/waypoint" + to_string(i) + "_z", waypoints_[i][2], -1.0);
    }

    /* initialize main modules */
    visualization_.reset(new PlanningVisualization(nh));
    planner_manager_.reset(new EGOPlannerManager);
    planner_manager_->initPlanModules(nh, visualization_);
    dir = POSITIVE;
    goal_last << 0,0,0;

    /* callback */
    exec_timer_ = nh.createTimer(ros::Duration(0.01), &EGOReplanFSM::execFSMCallback, this);
    safety_timer_ = nh.createTimer(ros::Duration(0.05), &EGOReplanFSM::checkCollisionCallback, this);

    odom_sub_ = nh.subscribe("/odom_map", 1, &EGOReplanFSM::odometryCallback, this);

    bspline_pub_ = nh.advertise<ego_planner::Bspline>("/planning/bspline", 10);
    data_disp_pub_ = nh.advertise<ego_planner::DataDisp>("/planning/data_display", 100);
    cmd_pub_ = nh.advertise<geometry_msgs::Twist>("/cmd_vel",100);
    adjust_cmd_pub_ = nh.advertise<std_msgs::UInt8>("/is_adjust_yaw",100);
    odom_adjust_pub_ = nh.advertise<nav_msgs::Odometry>("/odom_adjust",100);
    dir_pub = nh.advertise<std_msgs::UInt8>("/direction",100);
    stop_pub = nh.advertise<std_msgs::UInt8>("/emergency_stop",100);

    is_target_receive = false;

    if (target_type_ == TARGET_TYPE::MANUAL_TARGET)
      waypoint_sub_ = nh.subscribe("/way_point", 1, &EGOReplanFSM::goal_callback, this);
    else if (target_type_ == TARGET_TYPE::PRESET_TARGET)
    {
      ros::Duration(1.0).sleep();
      while (ros::ok() && !have_odom_)
        ros::spinOnce();
      planGlobalTrajbyGivenWps();
    }
    else
      cout << "Wrong target_type_ value! target_type_=" << target_type_ << endl;
  }

  void EGOReplanFSM::planGlobalTrajbyGivenWps()
  {
    std::vector<Eigen::Vector3d> wps(waypoint_num_);
    for (int i = 0; i < waypoint_num_; i++)
    {
      wps[i](0) = waypoints_[i][0];
      wps[i](1) = waypoints_[i][1];
      wps[i](2) = waypoints_[i][2];

      end_pt_ = wps.back();
    }
    bool success = planner_manager_->planGlobalTrajWaypoints(odom_pos_, Eigen::Vector3d::Zero(), Eigen::Vector3d::Zero(), wps, Eigen::Vector3d::Zero(), Eigen::Vector3d::Zero());

    for (size_t i = 0; i < (size_t)waypoint_num_; i++)
    {
      visualization_->displayGoalPoint(wps[i], Eigen::Vector4d(0, 0.5, 0.5, 1), 0.3, i);
      ros::Duration(0.001).sleep();
    }

    if (success)
    {

      /*** display ***/
      constexpr double step_size_t = 0.1;
      int i_end = floor(planner_manager_->global_data_.global_duration_ / step_size_t);
      std::vector<Eigen::Vector3d> gloabl_traj(i_end);
      for (int i = 0; i < i_end; i++)
      {
        gloabl_traj[i] = planner_manager_->global_data_.global_traj_.evaluate(i * step_size_t);
      }

      end_vel_.setZero();
      have_target_ = true;
      have_new_target_ = true;

      /*** FSM ***/
      // if (exec_state_ == WAIT_TARGET)
      changeFSMExecState(GEN_NEW_TRAJ, "TRIG");
      // else if (exec_state_ == EXEC_TRAJ)
      //   changeFSMExecState(REPLAN_TRAJ, "TRIG");

      // visualization_->displayGoalPoint(end_pt_, Eigen::Vector4d(1, 0, 0, 1), 0.3, 0);
      ros::Duration(0.001).sleep();
      visualization_->displayGlobalPathList(gloabl_traj, 0.1, 0);
      ros::Duration(0.001).sleep();
    }
    else
    {
      ROS_ERROR("Unable to generate global trajectory!");
    }
  }

  void EGOReplanFSM::waypointCallback(const nav_msgs::PathConstPtr &msg)
  {
    if (msg->poses[0].pose.position.z < -0.1)
      return;

    cout << "Triggered!" << endl;
    trigger_ = true;
    init_pt_ = odom_pos_;


    bool success = false;
    end_pt_ << msg->poses[0].pose.position.x, msg->poses[0].pose.position.y, 1.0;
    success = planner_manager_->planGlobalTraj(odom_pos_, odom_vel_, Eigen::Vector3d::Zero(), end_pt_, Eigen::Vector3d::Zero(), Eigen::Vector3d::Zero());

    visualization_->displayGoalPoint(end_pt_, Eigen::Vector4d(0, 0.5, 0.5, 1), 0.3, 0);

    if (success)
    {

      /*** display ***/
      constexpr double step_size_t = 0.1;
      int i_end = floor(planner_manager_->global_data_.global_duration_ / step_size_t);
      vector<Eigen::Vector3d> gloabl_traj(i_end);
      for (int i = 0; i < i_end; i++)
      {
        gloabl_traj[i] = planner_manager_->global_data_.global_traj_.evaluate(i * step_size_t);
      }

      end_vel_.setZero();
      have_target_ = true;
      have_new_target_ = true;

      /*** FSM ***/
      if (exec_state_ == WAIT_TARGET)
        changeFSMExecState(GEN_NEW_TRAJ, "TRIG");
      else if (exec_state_ == EXEC_TRAJ)
        changeFSMExecState(REPLAN_TRAJ, "TRIG");

      // visualization_->displayGoalPoint(end_pt_, Eigen::Vector4d(1, 0, 0, 1), 0.3, 0);
      visualization_->displayGlobalPathList(gloabl_traj, 0.1, 0);
    }
    else
    {
      ROS_ERROR("Unable to generate global trajectory!");
    }
  }

void EGOReplanFSM::goal_callback(const geometry_msgs::PoseStamped::ConstPtr &msg)
{
    end_pt_ << msg->pose.position.x, msg->pose.position.y, odom_pos_(2);

    //cout << "Triggered!" << endl;
    trigger_ = true;

    double error_x = msg->pose.position.x - odom_pos_(0);
    double error_y = msg->pose.position.y - odom_pos_(1);

    init_pt_ = odom_pos_;

    bool success = false;


    goal_last = end_pt_;

//    last_state_ = exec_state_;
//    yaw_start = atan2(error_y,error_x);
//    yaw_error = yaw_start-yaw;
//
//    //first step : calculate the yaw error
//    if(abs(yaw_error)>PI)
//    {
//        yaw_error = yaw_error - yaw_error/abs(yaw_error)*2*PI;
//    }
//    if(abs(yaw_error)>PI/2.0)
//    {
//        if(yaw>0)
//        {
//            yaw -= PI;
//        }else if(yaw<0)
//        {
//            yaw += PI;
//        }
//        changeDirection();
//        //yaw_error = - yaw_error/abs(yaw_error)*(PI-abs(yaw_error));
//        yaw_error = yaw_start - yaw;
//
//    }
//    if(abs(yaw_error)>yaw_error_max)
//    {
//        cmd_vel.twist.linear.x = 0;
//        cmd_vel.twist.angular.z = yaw_error/abs(yaw_error)*w_adjust;
//        bool success = false;
//        end_pt_ << msg->point.x, msg->point.y, msg->point.z;
//        success = planner_manager_->planGlobalTraj(odom_pos_,odom_vel_, Eigen::Vector3d::Zero(), end_pt_, Eigen::Vector3d::Zero(), Eigen::Vector3d::Zero());
//        changeFSMExecState(ADJUST_POSE, "TRIG");
//        return;
//    }

    success = planner_manager_->planGlobalTraj(odom_pos_,odom_vel_, Eigen::Vector3d::Zero(), end_pt_, Eigen::Vector3d::Zero(), Eigen::Vector3d::Zero());

    visualization_->displayGoalPoint(end_pt_, Eigen::Vector4d(0, 0.5, 0.5, 1), 0.3, 0);

    if (success)
    {
        /*** display ***/
        constexpr double step_size_t = 0.1;
        int i_end = floor(planner_manager_->global_data_.global_duration_ / step_size_t);
        vector<Eigen::Vector3d> gloabl_traj(i_end);
        for (int i = 0; i < i_end; i++)
        {
            gloabl_traj[i] = planner_manager_->global_data_.global_traj_.evaluate(i * step_size_t);
        }
        end_vel_.setZero();
        have_target_ = true;
        have_new_target_ = true;

        //goal is too close to current pose

        /*** FSM ***/
        if (exec_state_ == WAIT_TARGET)
        {
            changeFSMExecState(GEN_NEW_TRAJ, "TRIG");
            is_target_receive = true;
        }
        else if (exec_state_ == EXEC_TRAJ)
        {
            changeFSMExecState(REPLAN_TRAJ, "TRIG");
            is_target_receive=true;
        }

        visualization_->displayGlobalPathList(gloabl_traj, 0.1, 0);

        // visualization_->displayGoalPoint(end_pt_, Eigen::Vector4d(1, 0, 0, 1), 0.3, 0);
        //visualization_->displayGlobalPathList(gloabl_traj, 0.1, 0);
    }
    else
    {
        ROS_ERROR("Unable to generate global trajectory!");
    }
}


  void EGOReplanFSM::odometryCallback(const nav_msgs::OdometryConstPtr &msg)
  {
    odom_pos_(0) = msg->pose.pose.position.x;
    odom_pos_(1) = msg->pose.pose.position.y;
    odom_pos_(2) = msg->pose.pose.position.z;

    odom_vel_(0) = msg->twist.twist.linear.x;
    odom_vel_(1) = msg->twist.twist.linear.y;
    odom_vel_(2) = msg->twist.twist.linear.z;

    //odom_acc_ = estimateAcc( msg );

    odom_orient_.w() = msg->pose.pose.orientation.w;
    odom_orient_.x() = msg->pose.pose.orientation.x;
    odom_orient_.y() = msg->pose.pose.orientation.y;
    odom_orient_.z() = msg->pose.pose.orientation.z;

    tf::quaternionMsgToTF(msg->pose.pose.orientation,quat);
    tf::Matrix3x3(quat).getRPY(roll, pitch, raw_yaw);
    yaw = raw_yaw;

    if(dir==NEGATIVE)
    {
        if(yaw>0)
        {
            yaw -= PI;
        }else if(yaw<0)
        {
            yaw += PI;
        }
    }
      nav_msgs::Odometry odom_adjust;
      geometry_msgs::Quaternion quat=tf::createQuaternionMsgFromRollPitchYaw(roll,pitch,yaw);
      odom_adjust = *msg;
      odom_adjust.pose.pose.orientation = quat;
      odom_adjust_pub_.publish(odom_adjust);

    have_odom_ = true;
  }

  void EGOReplanFSM::changeFSMExecState(FSM_EXEC_STATE new_state, string pos_call)
  {

    if (new_state == exec_state_)
      continously_called_times_++;
    else
      continously_called_times_ = 1;

    static string state_str[7] = {"INIT", "WAIT_TARGET","ADJUST_POSE","GEN_NEW_TRAJ", "REPLAN_TRAJ", "EXEC_TRAJ", "EMERGENCY_STOP"};
    int pre_s = int(exec_state_);
    exec_state_ = new_state;
    cout << "[" + pos_call + "]: from " + state_str[pre_s] + " to " + state_str[int(new_state)] << endl;
  }

  void EGOReplanFSM::checkYawError() {
      yaw_error = yaw_start-yaw;
      //first step : find the real yaw error
      if(abs(yaw_error)>yaw_error_max)
      {
          //if yaw error is larger than PI,it means the symbol between current yaw and target yaw is different
          if(abs(yaw_error)>PI)
          {
              //calculate the real yaw error with symbol
              yaw_error = yaw_error - yaw_error/abs(yaw_error)*2*PI;
              //if real yaw error larger than PI/2, change the direction of robot
              if(abs(yaw_error)>PI/2)
              {
                  changeDirection();

              }
          }
          else
          {
              cmd_vel.linear.x = 0;
              cmd_vel.angular.z = yaw_error/abs(yaw_error)*w_adjust;

          }
      }
  }

  double EGOReplanFSM::calculateYawError(double yaw_cur,double yaw_target) {
      double error = yaw_target - yaw_cur;
      if(abs(error)>PI)
      {
          error = error - error/abs(error)*2*PI;
          return error;
      }
      else
      {
          return error;
      }
  }

  void EGOReplanFSM::changeDirection() {
      if(dir == POSITIVE)
      {
          setDirection(NEGATIVE);
      }else
      {
          setDirection(POSITIVE);
      }
  }

  void EGOReplanFSM::setDirection(DIRECTION new_dir) {
      dir = new_dir;
      std_msgs::UInt8 dir_new;
      dir_new.data = dir;
      dir_pub.publish(dir_new);
  }

  void EGOReplanFSM::syncDirectionWithTrajectoryYaw(double traj_yaw) {
      double raw_error = calculateYawError(raw_yaw, traj_yaw);
      DIRECTION desired_dir = std::abs(raw_error) > PI / 2.0 ? NEGATIVE : POSITIVE;
      setDirection(desired_dir);

      yaw = raw_yaw;
      if (dir == NEGATIVE)
      {
          if(yaw>0)
          {
              yaw -= PI;
          }else if(yaw<0)
          {
              yaw += PI;
          }
      }
      yaw_error = calculateYawError(yaw, traj_yaw);
  }

  std::pair<int, EGOReplanFSM::FSM_EXEC_STATE> EGOReplanFSM::timesOfConsecutiveStateCalls()
  {
    return std::pair<int, FSM_EXEC_STATE>(continously_called_times_, exec_state_);
  }

  void EGOReplanFSM::printFSMExecState()
  {
    static string state_str[7] = {"INIT", "WAIT_TARGET","ADJUST_POSE","GEN_NEW_TRAJ", "REPLAN_TRAJ", "EXEC_TRAJ", "EMERGENCY_STOP"};

    cout << "[FSM]: state: " + state_str[int(exec_state_)] << endl;
  }

void EGOReplanFSM::execFSMCallback(const ros::TimerEvent &e)
  {
    if (have_odom_)
    {
        if (planner_manager_->selectActiveObstacle(odom_pos_, odom_vel_))
        {
          planner_manager_->checkCOLREGs(odom_pos_, odom_vel_,
                                        planner_manager_->ts_pos_, 
                                        planner_manager_->ts_vel_);
        }
    }

    static int fsm_num = 0;
    fsm_num++;

    // 2. 局面信息打印逻辑 (合并到这�?
    if (fsm_num == 100) // �?1�?打印一�?
    {
      printFSMExecState();
      
      std::string scenario_name;
      switch (planner_manager_->current_scenario_) {
          case EGOPlannerManager::NONE:           scenario_name = "\033[1;32mSAFE (0)\033[0m"; break;
          case EGOPlannerManager::HEAD_ON:        scenario_name = "\033[1;31mHEAD-ON (1)\033[0m"; break;
          case EGOPlannerManager::CROSS_GIVE_WAY: scenario_name = "\033[1;33mCROSSING-GIVE-WAY (2)\033[0m"; break;
          case EGOPlannerManager::CROSS_STAND_ON: scenario_name = "\033[1;34mCROSSING-STAND-ON (3)\033[0m"; break;
          case EGOPlannerManager::OVERTAKING:     scenario_name = "\033[1;35mOVERTAKING (4)\033[0m"; break;
          default:                                scenario_name = "UNKNOWN"; break;
      }
      double current_dist = (planner_manager_->ts_pos_ - odom_pos_).norm();
      ROS_INFO("[COLREGs] Active: %s | Real-time State: %s | Dist: %.2f m",
               planner_manager_->active_obstacle_name_.c_str(), scenario_name.c_str(), current_dist);

      if (!have_odom_) cout << "no odom." << endl;
      if (!trigger_) cout << "wait for goal." << endl;
      fsm_num = 0;
    }

    switch (exec_state_)
    {
    case INIT:
    {
      if (!have_odom_)
      {
        return;
      }
      if (!trigger_)
      {
        return;
      }
      changeFSMExecState(WAIT_TARGET, "FSM");
      break;
    }

    case WAIT_TARGET:
    {
      if (!have_target_)
        return;
      else
      {
        changeFSMExecState(GEN_NEW_TRAJ, "FSM");
      }
      break;
    }

    case ADJUST_POSE:
    {
//        if(last_state_!=WAIT_TARGET&&last_state_!=EMERGENCY_STOP)
//        {
//            callEmergencyStop(odom_pos_);
//        }
        yaw_error = yaw_start-yaw;
        //first step : calculate the yaw error
        if(abs(yaw_error)>PI)
        {
            yaw_error = yaw_error - yaw_error/abs(yaw_error)*2*PI;
        }
        static int count=0;
        if(count%100==0)
        {
            string directions[2] = {"POSITIVE","NAGETIVE"};
            cout << "direction : "<<directions[int(dir)]<<endl;
            cout<<"current yaw: "<<yaw<<endl;
            cout<<"yaw error : "<<yaw_error<<endl;
            count=0;
        }
        count+=1;
        if(abs(yaw_error)>yaw_error_max)
        {
            is_adjust_pose.data = 1;
            cmd_vel.linear.x = 0;
            cmd_vel.angular.z = yaw_error/abs(yaw_error)*w_adjust;
            cmd_pub_.publish(cmd_vel);
            adjust_cmd_pub_.publish(is_adjust_pose);
        }else
        {
            is_adjust_pose.data = 0;
            cmd_vel.linear.x = 0;
            cmd_vel.angular.z =0;
            cmd_pub_.publish(cmd_vel);
            changeFSMExecState(EXEC_TRAJ, "FSM");
            adjust_cmd_pub_.publish(is_adjust_pose);
            auto info = &planner_manager_->local_data_;
            info->start_time_ = ros::Time::now();
            publishBspline();
        }
        break;
    }

    case GEN_NEW_TRAJ:
    {
      start_pt_ = odom_pos_;
      start_vel_ << 0,0,0;
      start_acc_.setZero();

      // Eigen::Vector3d rot_x = odom_orient_.toRotationMatrix().block(0, 0, 3, 1);
      // start_yaw_(0)         = atan2(rot_x(1), rot_x(0));
      // start_yaw_(1) = start_yaw_(2) = 0.0;

      bool flag_random_poly_init;
      if (timesOfConsecutiveStateCalls().first == 1)
        flag_random_poly_init = false;
      else
        flag_random_poly_init = true;

      bool success = callReboundReplan(true, flag_random_poly_init);
      if (success)
      {
          Eigen::Vector3d vel_start = planner_manager_->local_data_.velocity_traj_.evaluateDeBoor(0.1);
          yaw_start = atan2(vel_start(1),vel_start(0));
          cout<<"yaw start : "<<yaw_start<<endl;
          syncDirectionWithTrajectoryYaw(yaw_start);

          cout<<"yaw error : "<<yaw_error<<endl;
          if(abs(yaw_error)>yaw_error_max)
          {
              cmd_vel.linear.x = 0;
              cmd_vel.angular.z = yaw_error/abs(yaw_error)*w_adjust;
              changeFSMExecState(ADJUST_POSE, "TRIG");
              last_state_ = GEN_NEW_TRAJ;
              is_target_receive=false;
              return;
          }
          cout<<"yaw error : "<<yaw_error<<endl;
        auto info = &planner_manager_->local_data_;
        info->start_time_ = ros::Time::now();
        publishBspline();
        changeFSMExecState(EXEC_TRAJ, "FSM");
        flag_escape_emergency_ = true;
      }
      else
      {
        changeFSMExecState(GEN_NEW_TRAJ, "FSM");
      }
      break;
    }

    case REPLAN_TRAJ:
    {

      if (planFromCurrentTraj())
      {
          Eigen::Vector3d vel_start = planner_manager_->local_data_.velocity_traj_.evaluateDeBoor(0.1);
          yaw_start = atan2(vel_start(1),vel_start(0));
          if (force_head_on_return_target_once_)
          {
            setDirection(POSITIVE);
            force_head_on_return_target_once_ = false;
          }
          else
          {
            syncDirectionWithTrajectoryYaw(yaw_start);
          }

          auto info = &planner_manager_->local_data_;
          info->start_time_ = ros::Time::now();
          std_msgs::UInt8 stop_cmd;
          stop_cmd.data = 0;
          stop_pub.publish(stop_cmd);
          publishBspline();
          changeFSMExecState(EXEC_TRAJ, "FSM");
      }
      else
      {
          changeFSMExecState(REPLAN_TRAJ, "FSM");
      }

      break;
    }

    case EXEC_TRAJ:
    {
      /* determine if need to replan */
      LocalTrajData *info = &planner_manager_->local_data_;
      ros::Time time_now = ros::Time::now();
      double t_cur = (time_now - info->start_time_).toSec();
      t_cur = min(info->duration_, t_cur);

      Eigen::Vector3d pos = info->position_traj_.evaluateDeBoorT(t_cur);

      /* && (end_pt_ - pos).norm() < 0.5 */
      if (t_cur > info->duration_ - 1e-2)
      {
        if (planner_manager_->has_active_obstacle_ &&
            (planner_manager_->current_scenario_ == EGOPlannerManager::HEAD_ON ||
             planner_manager_->current_scenario_ == EGOPlannerManager::OVERTAKING ||
             planner_manager_->current_scenario_ == EGOPlannerManager::CROSS_GIVE_WAY))
        {
          changeFSMExecState(REPLAN_TRAJ, "COLREGsContinue");
          return;
        }

        if (was_in_crossing_maneuver_)
        {
          was_in_crossing_maneuver_ = false;
          force_crossing_poly_replan_once_ = true;
          ROS_WARN("CROSSING cleared at trajectory end: replan toward global target");
          changeFSMExecState(REPLAN_TRAJ, "CROSSING_CLEAR");
          return;
        }

        have_target_ = false;

        changeFSMExecState(WAIT_TARGET, "FSM");
        return;
      }
      else if ((end_pt_ - pos).norm() < no_replan_thresh_)
      {
        // cout << "near end" << endl;
        return;
      }
      else if (planner_manager_->has_active_obstacle_ &&
               planner_manager_->current_scenario_ == EGOPlannerManager::HEAD_ON)
      {
        was_in_head_on_maneuver_ = true;
        static ros::Time last_head_on_replan_time(0);
        const double dcpa = planner_manager_->getLastDCPA();
        const double tcpa = planner_manager_->getLastTCPA();
        const double safe_dcpa = planner_manager_->getSafeDCPA();
        Eigen::Vector2d rel_obs = (planner_manager_->ts_pos_ - odom_pos_).head<2>();
        Eigen::Vector2d course;
        if (planner_manager_->hasHeadOnManeuverLock() &&
            planner_manager_->getHeadOnLockCourse().norm() > 0.05)
        {
          course = planner_manager_->getHeadOnLockCourse().normalized();
        }
        else if (odom_vel_.head<2>().norm() > 0.05)
        {
          course = odom_vel_.head<2>().normalized();
        }
        else
        {
          Eigen::Vector2d to_goal = (end_pt_ - odom_pos_).head<2>();
          course = to_goal.norm() > 1e-3 ? to_goal.normalized() : Eigen::Vector2d(1.0, 0.0);
        }
        double lateral_obs = course.x() * rel_obs.y() - course.y() * rel_obs.x();
        bool already_maneuvering = lateral_obs > 3.0;
        bool urgent_head_on =
            planner_manager_->current_scenario_ == EGOPlannerManager::HEAD_ON &&
            tcpa > 0.0 &&
            (tcpa < 8.0 || dcpa < safe_dcpa * 1.2);

        const bool locked_head_on = planner_manager_->hasHeadOnManeuverLock();
        const double head_on_replan_interval = (urgent_head_on && !locked_head_on) ? 0.8 : 1.5;
        const bool need_head_on_replan = !already_maneuvering || (urgent_head_on && !locked_head_on);

        if (need_head_on_replan &&
            (time_now - last_head_on_replan_time).toSec() > head_on_replan_interval)
        {
          if (urgent_head_on && !locked_head_on)
          {
            std_msgs::UInt8 stop_cmd;
            stop_cmd.data = 1;
            stop_pub.publish(stop_cmd);
          }
          last_head_on_replan_time = time_now;
          changeFSMExecState(REPLAN_TRAJ, "HEAD_ON");
        }
        return;
      }
      else if (planner_manager_->has_active_obstacle_ &&
               planner_manager_->current_scenario_ == EGOPlannerManager::OVERTAKING)
      {
        was_in_overtaking_maneuver_ = true;
        static ros::Time last_overtaking_replan_time(0);
        Eigen::Vector2d rel_obs = (planner_manager_->ts_pos_ - odom_pos_).head<2>();
        Eigen::Vector2d course;
        if (planner_manager_->hasOvertakingManeuverLock() &&
            planner_manager_->getOvertakingLockCourse().norm() > 0.05)
        {
          course = planner_manager_->getOvertakingLockCourse().normalized();
        }
        else if (odom_vel_.head<2>().norm() > 0.05)
        {
          course = odom_vel_.head<2>().normalized();
        }
        else
        {
          Eigen::Vector2d to_goal = (end_pt_ - odom_pos_).head<2>();
          course = to_goal.norm() > 1e-3 ? to_goal.normalized() : Eigen::Vector2d(1.0, 0.0);
        }
        double lateral_obs = course.x() * rel_obs.y() - course.y() * rel_obs.x();
        double along_obs = rel_obs.dot(course);
        const double safe_dcpa = planner_manager_->getSafeDCPA();
        const double desired_left_offset = std::max(safe_dcpa * 1.1, 5.5);
        Eigen::Vector2d left_normal(-course.y(), course.x());
        Eigen::Vector2d lane_origin = odom_pos_.head<2>();
        if (planner_manager_->hasOvertakingManeuverLock())
        {
          lane_origin = planner_manager_->getOvertakingObstacleTrackOrigin();
        }
        double current_left_offset = (odom_pos_.head<2>() - lane_origin).dot(left_normal);

        bool still_needs_port_shift =
            along_obs > -safe_dcpa * 2.0 &&
            current_left_offset < desired_left_offset * 0.35;

        if (still_needs_port_shift &&
            (time_now - last_overtaking_replan_time).toSec() > 1.2)
        {
          last_overtaking_replan_time = time_now;
          ROS_WARN("OVERTAKING: replan only to enter port lane, left_offset=%.2f/%.2f, rel_lateral=%.2f, rel_along=%.2f",
                   current_left_offset, desired_left_offset, lateral_obs, along_obs);
          changeFSMExecState(REPLAN_TRAJ, "OVERTAKING");
        }
        return;
      }
      else if (planner_manager_->has_active_obstacle_ &&
               planner_manager_->current_scenario_ == EGOPlannerManager::CROSS_GIVE_WAY)
      {
        was_in_crossing_maneuver_ = true;
        static ros::Time last_crossing_replan_time(0);
        const double dcpa = planner_manager_->getLastDCPA();
        const double tcpa = planner_manager_->getLastTCPA();
        const double safe_dcpa = planner_manager_->getSafeDCPA();
        const double crossing_replan_interval = planner_manager_->hasCrossingManeuverLock() ? 0.8 : 1.2;
        bool need_crossing_replan = tcpa > 0.0 && (tcpa < 10.0 || dcpa < safe_dcpa * 1.4 || planner_manager_->hasCrossingManeuverLock());
        if (need_crossing_replan &&
            (time_now - last_crossing_replan_time).toSec() > crossing_replan_interval)
        {
          last_crossing_replan_time = time_now;
          ROS_WARN("CROSSING: replan starboard drift/straight stage, DCPA=%.2f, TCPA=%.2f", dcpa, tcpa);
          changeFSMExecState(REPLAN_TRAJ, "CROSSING");
        }
        return;
      }
      else if (was_in_crossing_maneuver_)
      {
        was_in_crossing_maneuver_ = false;
        force_crossing_poly_replan_once_ = true;
        ROS_WARN("CROSSING cleared: forcing one polynomial replan back toward global target");
        changeFSMExecState(REPLAN_TRAJ, "CROSSING_CLEAR");
        return;
      }
      else if (was_in_overtaking_maneuver_)
      {
        was_in_overtaking_maneuver_ = false;
        force_overtaking_poly_replan_once_ = true;
        ROS_WARN("OVERTAKING cleared: forcing one polynomial replan back toward global target");
        changeFSMExecState(REPLAN_TRAJ, "OVERTAKING_CLEAR");
        return;
      }
      else if (was_in_head_on_maneuver_)
      {
        was_in_head_on_maneuver_ = false;
        force_head_on_poly_replan_once_ = true;
        force_head_on_return_target_once_ = true;
        ROS_WARN("HEAD_ON cleared: forcing one polynomial replan back toward global target");
        changeFSMExecState(REPLAN_TRAJ, "HEAD_ON_CLEAR");
        return;
      }
      else if ((info->start_pos_ - pos).norm() < replan_thresh_)
      {
        // cout << "near start" << endl;
        return;
      }
      else
      {
        changeFSMExecState(REPLAN_TRAJ, "FSM");
      }
      break;
    }

    case EMERGENCY_STOP:
    {

      if (flag_escape_emergency_) // Avoiding repeated calls
      {
        callEmergencyStop(odom_pos_);
      }
      else
      {
        if (odom_vel_.norm() < 0.1)
          changeFSMExecState(GEN_NEW_TRAJ, "FSM");
      }

      flag_escape_emergency_ = false;
      break;
    }
    }

    data_disp_.header.stamp = ros::Time::now();
    data_disp_pub_.publish(data_disp_);
  }

  bool EGOReplanFSM::planFromCurrentTraj()
  {

    LocalTrajData *info = &planner_manager_->local_data_;
    ros::Time time_now = ros::Time::now();
    double t_cur = (time_now - info->start_time_).toSec();

    //cout << "info->velocity_traj_=" << info->velocity_traj_.get_control_points() << endl;

    start_pt_ = odom_pos_;
    start_vel_ = odom_vel_;
    start_acc_.setZero();

    yaw_start = atan2((end_pt_-odom_pos_)(1),(end_pt_-odom_pos_)(0));
    yaw_error = calculateYawError(yaw, yaw_start);

    if(is_target_receive)
    {
        syncDirectionWithTrajectoryYaw(yaw_start);
        if(abs(yaw_error)>yaw_error_max)
        {
            start_acc_ <<-start_acc_(0),-start_acc_(1),0;
            //callEmergencyStop(odom_pos_);
            std_msgs::UInt8 stop_cmd;
            stop_cmd.data = 1;
            stop_pub.publish(stop_cmd);

        }
        is_target_receive = false;
    }
    //first step : calculate the yaw error


    const bool force_poly_init = force_head_on_poly_replan_once_ || force_overtaking_poly_replan_once_ || force_crossing_poly_replan_once_;
    const bool force_forward_direction = force_head_on_poly_replan_once_ || force_crossing_poly_replan_once_;
    force_head_on_poly_replan_once_ = false;
    force_overtaking_poly_replan_once_ = false;
    force_crossing_poly_replan_once_ = false;

    bool success = callReboundReplan(force_poly_init, false);
    if (success && force_forward_direction)
    {
      setDirection(POSITIVE);
    }
    if (!success)
    {
      success = callReboundReplan(true, false);
      //changeFSMExecState(EXEC_TRAJ, "FSM");
      if (!success)
      {
        success = callReboundReplan(true, true);
        if (!success)
        {
          return false;
        }
      }
    }

    return true;
  }

  void EGOReplanFSM::checkCollisionCallback(const ros::TimerEvent &e)
  {
    LocalTrajData *info = &planner_manager_->local_data_;
    auto map = planner_manager_->grid_map_;

    if (exec_state_ == WAIT_TARGET || info->start_time_.toSec() < 1e-5)
      return;

    /* ---------- check trajectory ---------- */
    constexpr double time_step = 0.01;
    double t_cur = (ros::Time::now() - info->start_time_).toSec();
    double t_2_3 = info->duration_ * 2 / 3;
    for (double t = t_cur; t < info->duration_; t += time_step)
    {
      if (t_cur < t_2_3 && t >= t_2_3) // If t_cur < t_2_3, only the first 2/3 partition of the trajectory is considered valid and will get checked.
        break;

      Eigen::Vector3d pos_cur = info->position_traj_.evaluateDeBoorT(t);
      Eigen::Vector2d pos_cur2d;
      pos_cur2d << pos_cur(0),pos_cur(1);
      if (map->getInflateOccupancy2d(pos_cur2d))
      {
        if (planFromCurrentTraj()) // Make a chance
        {
          changeFSMExecState(EXEC_TRAJ, "SAFETY");
          return;
        }
        else
        {
          if (t - t_cur < emergency_time_) // 0.8s of emergency time
          {
            ROS_WARN("Suddenly discovered obstacles. emergency stop! time=%f", t - t_cur);
            changeFSMExecState(EMERGENCY_STOP, "SAFETY");
          }
          else
          {
            //ROS_WARN("current traj in collision, replan.");
            changeFSMExecState(REPLAN_TRAJ, "SAFETY");
          }
          return;
        }
        break;
      }
    }
  }

  bool EGOReplanFSM::callReboundReplan(bool flag_use_poly_init, bool flag_randomPolyTraj)
  {

    getLocalTarget();
    start_pt_(2) = odom_pos_(2);
    start_vel_(2) = 0;
    start_acc_(2) = 0;
    local_target_pt_(2) = odom_pos_(2);
    local_target_vel_(2) = 0;

    bool plan_success =
        planner_manager_->reboundReplan(start_pt_, start_vel_, start_acc_, local_target_pt_, local_target_vel_, (have_new_target_ || flag_use_poly_init), flag_randomPolyTraj);
    have_new_target_ = false;

    cout << "final_plan_success=" << plan_success << endl;

    if (plan_success)
    {
      auto info = &planner_manager_->local_data_;
      //publishBspline();
      Eigen::MatrixXd control_points = info->position_traj_.get_control_points();
      for(int i=0;i<control_points.cols();i++) control_points.col(i)(2) = odom_pos_(2);
      visualization_->displayOptimalList(control_points, 0);
    }

    return plan_success;
  }

  bool EGOReplanFSM::callEmergencyStop(Eigen::Vector3d stop_pos)
  {

    planner_manager_->EmergencyStop(stop_pos);

    auto info = &planner_manager_->local_data_;

    /* publish traj */
    ego_planner::Bspline bspline;
    bspline.order = 3;
    bspline.start_time = info->start_time_;
    bspline.traj_id = info->traj_id_;

    Eigen::MatrixXd pos_pts = info->position_traj_.getControlPoint();
    bspline.pos_pts.reserve(pos_pts.cols());
    for (int i = 0; i < pos_pts.cols(); ++i)
    {
      geometry_msgs::Point pt;
      pt.x = pos_pts(0, i);
      pt.y = pos_pts(1, i);
      pt.z = pos_pts(2, i);
      bspline.pos_pts.push_back(pt);
    }

    Eigen::VectorXd knots = info->position_traj_.getKnot();
    bspline.knots.reserve(knots.rows());
    for (int i = 0; i < knots.rows(); ++i)
    {
      bspline.knots.push_back(knots(i));
    }

    bspline_pub_.publish(bspline);

    return true;
  }

  bool EGOReplanFSM::adjustLocalTargetForHeadOn(double stop_dist)
  {
    const bool raw_target_near_final = (end_pt_ - local_target_pt_).norm() < stop_dist;
    if (!planner_manager_->has_active_obstacle_ ||
        planner_manager_->current_scenario_ != EGOPlannerManager::HEAD_ON ||
        raw_target_near_final)
    {
      return false;
    }

    Eigen::Vector2d start2d = start_pt_.head<2>();
    Eigen::Vector2d goal_vec = (end_pt_ - start_pt_).head<2>();
    double goal_dist = goal_vec.norm();
    if (goal_dist <= 1e-3)
      return false;

    Eigen::Vector2d goal_dir = goal_vec / goal_dist;
    if (planner_manager_->hasHeadOnManeuverLock() &&
        planner_manager_->getHeadOnLockCourse().norm() > 0.05)
    {
      goal_dir = planner_manager_->getHeadOnLockCourse().normalized();
    }

    Eigen::Vector2d target_vec = (local_target_pt_ - start_pt_).head<2>();
    double target_along = target_vec.dot(goal_dir);
    double target_lateral = goal_dir.x() * target_vec.y() - goal_dir.y() * target_vec.x();
    double lookahead = std::min(planning_horizen_, goal_dist);
    double min_forward = std::min(lookahead * 0.45, goal_dist);

    Eigen::Vector2d obs_rel = (planner_manager_->ts_pos_ - start_pt_).head<2>();
    double obs_along = obs_rel.dot(goal_dir);
    double obs_lateral = goal_dir.x() * obs_rel.y() - goal_dir.y() * obs_rel.x();
    const double safe_dcpa = planner_manager_->getSafeDCPA();

    bool target_points_to_obstacle =
        obs_along > 0.0 &&
        std::abs(obs_lateral) < safe_dcpa * 1.4 &&
        target_along > obs_along - safe_dcpa * 1.5 &&
        target_along < obs_along + safe_dcpa * 2.5 &&
        std::abs(target_lateral) < safe_dcpa * 1.2;
    bool locked_head_on_target_leaves_lane =
        planner_manager_->hasHeadOnManeuverLock() &&
        obs_along > safe_dcpa * 1.5 &&
        target_lateral > -safe_dcpa * 0.8;

    if (target_along >= min_forward &&
        target_vec.dot(goal_vec) > 0.0 &&
        !target_points_to_obstacle &&
        !locked_head_on_target_leaves_lane)
    {
      return false;
    }

    Eigen::Vector2d right_normal(goal_dir.y(), -goal_dir.x());
    const double lane_offset = std::max(safe_dcpa * 1.1, 5.5);
    Eigen::Vector2d lane_origin = start2d;
    double current_along = 0.0;
    if (planner_manager_->hasHeadOnManeuverLock())
    {
      lane_origin = planner_manager_->getHeadOnObstacleTrackOrigin();
      current_along = (start2d - lane_origin).dot(goal_dir);
    }

    Eigen::Vector2d corrected = lane_origin + goal_dir * (current_along + lookahead) + right_normal * lane_offset;

    ROS_WARN_THROTTLE(0.5,
                      "Local target corrected toward goal: old=(%.2f, %.2f), new=(%.2f, %.2f), obstacle_risk=%d",
                      local_target_pt_.x(), local_target_pt_.y(),
                      corrected.x(), corrected.y(),
                      target_points_to_obstacle ? 1 : 0);
    local_target_pt_.x() = corrected.x();
    local_target_pt_.y() = corrected.y();
    return true;
  }
  bool EGOReplanFSM::adjustLocalTargetForOvertaking(double stop_dist)
  {
    const bool raw_target_near_final = (end_pt_ - local_target_pt_).norm() < stop_dist;
    if (!planner_manager_->has_active_obstacle_ ||
        planner_manager_->current_scenario_ != EGOPlannerManager::OVERTAKING ||
        raw_target_near_final)
    {
      return false;
    }

    Eigen::Vector2d start2d = start_pt_.head<2>();
    Eigen::Vector2d goal_vec = (end_pt_ - start_pt_).head<2>();
    double goal_dist = goal_vec.norm();
    if (goal_dist <= 1e-3)
      return false;

    Eigen::Vector2d goal_dir = goal_vec / goal_dist;
    if (planner_manager_->hasOvertakingManeuverLock() &&
        planner_manager_->getOvertakingLockCourse().norm() > 0.05)
    {
      goal_dir = planner_manager_->getOvertakingLockCourse().normalized();
    }

    Eigen::Vector2d target_vec = (local_target_pt_ - start_pt_).head<2>();
    double target_along = target_vec.dot(goal_dir);
    double target_lateral = goal_dir.x() * target_vec.y() - goal_dir.y() * target_vec.x();
    double lookahead = std::min(planning_horizen_, goal_dist);
    double min_forward = std::min(lookahead * 0.45, goal_dist);

    Eigen::Vector2d obs_rel = (planner_manager_->ts_pos_ - start_pt_).head<2>();
    double obs_along = obs_rel.dot(goal_dir);
    double obs_lateral = goal_dir.x() * obs_rel.y() - goal_dir.y() * obs_rel.x();
    const double safe_dcpa = planner_manager_->getSafeDCPA();

    bool target_points_to_obstacle =
        obs_along > -safe_dcpa &&
        std::abs(obs_lateral) < safe_dcpa * 1.4 &&
        target_along > obs_along - safe_dcpa * 1.5 &&
        target_along < obs_along + safe_dcpa * 3.0 &&
        std::abs(target_lateral) < safe_dcpa * 1.2;
    bool locked_overtaking_target_leaves_lane =
        planner_manager_->hasOvertakingManeuverLock() &&
        obs_along > -safe_dcpa * 2.0 &&
        target_lateral < safe_dcpa * 0.8;

    if (target_along >= min_forward &&
        target_vec.dot(goal_vec) > 0.0 &&
        !target_points_to_obstacle &&
        !locked_overtaking_target_leaves_lane)
    {
      return false;
    }

    Eigen::Vector2d left_normal(-goal_dir.y(), goal_dir.x());
    const double lane_offset = std::max(safe_dcpa * 1.1, 5.5);
    Eigen::Vector2d lane_origin = start2d;
    double current_along = 0.0;
    if (planner_manager_->hasOvertakingManeuverLock())
    {
      lane_origin = planner_manager_->getOvertakingObstacleTrackOrigin();
      current_along = (start2d - lane_origin).dot(goal_dir);
    }

    Eigen::Vector2d corrected = lane_origin + goal_dir * (current_along + lookahead) + left_normal * lane_offset;

    ROS_WARN_THROTTLE(0.5,
                      "Overtaking local target corrected: old=(%.2f, %.2f), new=(%.2f, %.2f), obstacle_risk=%d",
                      local_target_pt_.x(), local_target_pt_.y(),
                      corrected.x(), corrected.y(),
                      target_points_to_obstacle ? 1 : 0);
    local_target_pt_.x() = corrected.x();
    local_target_pt_.y() = corrected.y();
    return true;
  }
  bool EGOReplanFSM::adjustLocalTargetForCrossing(double stop_dist)
  {
    const bool raw_target_near_final = (end_pt_ - local_target_pt_).norm() < stop_dist;
    if (!planner_manager_->has_active_obstacle_ ||
        planner_manager_->current_scenario_ != EGOPlannerManager::CROSS_GIVE_WAY ||
        raw_target_near_final)
    {
      return false;
    }

    Eigen::Vector2d start2d = start_pt_.head<2>();
    Eigen::Vector2d goal_vec = (end_pt_ - start_pt_).head<2>();
    double goal_dist = goal_vec.norm();
    if (goal_dist <= 1e-3)
      return false;
    Eigen::Vector2d goal_dir = goal_vec / goal_dist;

    if (planner_manager_->hasCrossingManeuverLock())
    {
      Eigen::Vector2d track_course = planner_manager_->getCrossingTrackCourse();
      if (track_course.norm() > 0.05)
      {
        track_course.normalize();
        Eigen::Vector2d track_normal(-track_course.y(), track_course.x());
        Eigen::Vector2d track_origin = planner_manager_->getCrossingTrackOrigin();
        const double current_side = (start2d - track_origin).dot(track_normal);
        const double initial_side = planner_manager_->getCrossingInitialSide();
        if (std::abs(initial_side) > 0.05 && initial_side * current_side < -0.25)
        {
          return false;
        }
      }
    }

    double current_target_along = (local_target_pt_ - start_pt_).head<2>().dot(goal_dir);
    if (current_target_along < 1.0)
    {
      current_target_along = std::min(planning_horizen_, goal_dist);
    }
    const double lookahead = std::min(goal_dist, std::max(3.0, std::min(planning_horizen_, current_target_along)));
    Eigen::Vector2d corrected = start2d + goal_dir * lookahead;

    if ((end_pt_.head<2>() - corrected).norm() < stop_dist)
    {
      corrected = end_pt_.head<2>();
    }

    local_target_pt_.x() = corrected.x();
    local_target_pt_.y() = corrected.y();

    const double current_speed = odom_vel_.head<2>().norm();
    const double target_speed = std::min(planner_manager_->pp_.max_vel_ * 0.65,
                                         std::max(0.45, current_speed * 0.75));
    local_target_vel_.x() = goal_dir.x() * target_speed;
    local_target_vel_.y() = goal_dir.y() * target_speed;

    ROS_WARN_THROTTLE(0.5,
                      "CROSSING local target kept on goal direction: target=(%.2f, %.2f), lookahead=%.2f",
                      local_target_pt_.x(), local_target_pt_.y(), lookahead);
    return true;
  }
  void EGOReplanFSM::getLocalTarget()
  {
    double t;

    if (force_head_on_return_target_once_)
    {
      Eigen::Vector2d to_goal = (end_pt_ - start_pt_).head<2>();
      double goal_dist = to_goal.norm();
      if (goal_dist > 1e-3)
      {
        Eigen::Vector2d goal_dir = to_goal / goal_dist;
        Eigen::Vector2d current_dir = odom_vel_.head<2>();
        if (current_dir.norm() < 0.2 && planner_manager_->getHeadOnLockCourse().norm() > 0.05)
        {
          current_dir = planner_manager_->getHeadOnLockCourse();
        }
        if (current_dir.norm() < 1e-3 || current_dir.dot(goal_dir) < 0.0)
        {
          current_dir = goal_dir;
        }
        else
        {
          current_dir.normalize();
        }

        Eigen::Vector2d return_dir = current_dir * 0.65 + goal_dir * 0.35;
        if (return_dir.norm() < 1e-3 || return_dir.dot(goal_dir) < 0.2)
        {
          return_dir = goal_dir;
        }
        else
        {
          return_dir.normalize();
        }

        double lookahead = std::min(std::min(planning_horizen_ * 0.35, 4.0), goal_dist);
        Eigen::Vector2d target2d = start_pt_.head<2>() + return_dir * lookahead;
        local_target_pt_ << target2d.x(), target2d.y(), odom_pos_(2);
        const double target_speed = std::min(planner_manager_->pp_.max_vel_, std::max(0.5, odom_vel_.head<2>().norm()));
        local_target_vel_ << return_dir.x() * target_speed, return_dir.y() * target_speed, 0.0;
        ROS_WARN("HEAD_ON cleared: smooth return target set to (%.2f, %.2f), final goal=(%.2f, %.2f)",
                 local_target_pt_.x(), local_target_pt_.y(), end_pt_.x(), end_pt_.y());
        return;
      }
    }

    double t_step = planning_horizen_ / 20 / planner_manager_->pp_.max_vel_;
    double dist_min = 9999, dist_min_t = 0.0;
    double progress_start = planner_manager_->global_data_.last_progress_time_;
    Eigen::Vector3d progress_pos = planner_manager_->global_data_.getPosition(progress_start);
    if ((progress_pos - start_pt_).norm() > planning_horizen_)
    {
      ROS_WARN("last_progress_time_ stale, resyncing global progress from %.2f", progress_start);
      for (double tc = 0.0; tc < planner_manager_->global_data_.global_duration_; tc += t_step)
      {
        Eigen::Vector3d pos_t = planner_manager_->global_data_.getPosition(tc);
        double dist = (pos_t - start_pt_).norm();
        if (dist < dist_min)
        {
          dist_min = dist;
          dist_min_t = tc;
        }
      }
      progress_start = dist_min_t;
      planner_manager_->global_data_.last_progress_time_ = progress_start;
      dist_min = 9999;
      dist_min_t = progress_start;
    }

    for (t = progress_start; t < planner_manager_->global_data_.global_duration_; t += t_step)
    {
      Eigen::Vector3d pos_t = planner_manager_->global_data_.getPosition(t);
      double dist = (pos_t - start_pt_).norm();

      if (t < progress_start + 1e-5 && dist > planning_horizen_)
      {
        ROS_WARN("global progress still far after resync, using smooth forward local target.");
        Eigen::Vector2d to_goal = (end_pt_ - start_pt_).head<2>();
        double goal_dist = to_goal.norm();
        if (goal_dist > 1e-3)
        {
          Eigen::Vector2d goal_dir = to_goal / goal_dist;
          Eigen::Vector2d current_dir = odom_vel_.head<2>();
          if (current_dir.norm() < 0.2 && planner_manager_->getHeadOnLockCourse().norm() > 0.05)
          {
            current_dir = planner_manager_->getHeadOnLockCourse();
          }
          if (current_dir.norm() < 1e-3 || current_dir.dot(goal_dir) < 0.0)
          {
            current_dir = goal_dir;
          }
          else
          {
            current_dir.normalize();
          }
          Eigen::Vector2d return_dir = current_dir * 0.65 + goal_dir * 0.35;
          if (return_dir.norm() < 1e-3 || return_dir.dot(goal_dir) < 0.2)
          {
            return_dir = goal_dir;
          }
          else
          {
            return_dir.normalize();
          }
          double lookahead = std::min(std::min(planning_horizen_ * 0.35, 4.0), goal_dist);
          Eigen::Vector2d target2d = start_pt_.head<2>() + return_dir * lookahead;
          local_target_pt_ << target2d.x(), target2d.y(), odom_pos_(2);
          local_target_vel_ << return_dir.x() * planner_manager_->pp_.max_vel_,
                               return_dir.y() * planner_manager_->pp_.max_vel_,
                               0.0;
        }
        break;
      }
      if (dist < dist_min)
      {
        dist_min = dist;
        dist_min_t = t;
      }
      if (dist >= planning_horizen_)
      {
        local_target_pt_ = pos_t;
        planner_manager_->global_data_.last_progress_time_ = dist_min_t;
        break;
      }
    }
    if (t > planner_manager_->global_data_.global_duration_) // Last global point
    {
      local_target_pt_ = end_pt_;
    }

    const double stop_dist = (planner_manager_->pp_.max_vel_ * planner_manager_->pp_.max_vel_) /
                             (2 * planner_manager_->pp_.max_acc_);
    const bool local_target_corrected = adjustLocalTargetForHeadOn(stop_dist) ||
                                       adjustLocalTargetForOvertaking(stop_dist) ||
                                       adjustLocalTargetForCrossing(stop_dist);
    const bool near_final_target = (end_pt_ - local_target_pt_).norm() < stop_dist;
    if (near_final_target)
    {
      // local_target_vel_ = (end_pt_ - init_pt_).normalized() * planner_manager_->pp_.max_vel_ * (( end_pt_ - local_target_pt_ ).norm() / ((planner_manager_->pp_.max_vel_*planner_manager_->pp_.max_vel_)/(2*planner_manager_->pp_.max_acc_)));
      // cout << "A" << endl;
      local_target_vel_ = Eigen::Vector3d::Zero();
    }
    else
    {
      local_target_vel_ = planner_manager_->global_data_.getVelocity(t);
      // cout << "AA" << endl;
    }

    if (local_target_corrected && !near_final_target)
    {
      Eigen::Vector2d corrected_target_dir = (local_target_pt_ - start_pt_).head<2>();
      if (corrected_target_dir.norm() > 1e-3)
      {
        corrected_target_dir.normalize();
        double target_speed = std::min(planner_manager_->pp_.max_vel_,
                                       std::max(0.5, odom_vel_.head<2>().norm()));
        if (planner_manager_->current_scenario_ == EGOPlannerManager::CROSS_GIVE_WAY)
        {
          target_speed = std::min(planner_manager_->pp_.max_vel_ * 0.65,
                                  std::max(0.45, odom_vel_.head<2>().norm() * 0.75));
        }
        local_target_vel_.x() = corrected_target_dir.x() * target_speed;
        local_target_vel_.y() = corrected_target_dir.y() * target_speed;
      }
    }
  }

  void EGOReplanFSM::publishBspline() {

      auto info = &planner_manager_->local_data_;
      info->start_time_ = ros::Time::now();
      /* publish traj */
      ego_planner::Bspline bspline;
      bspline.order = 3;
      bspline.start_time = info->start_time_;
      bspline.traj_id = info->traj_id_;

      Eigen::MatrixXd pos_pts = info->position_traj_.getControlPoint();
      //cout<<"optimal point : "<<endl<<pos_pts<<endl;
      bspline.pos_pts.reserve(pos_pts.cols());
      Eigen::Vector3d point_temp;
      for (int i = 0; i < pos_pts.cols(); ++i)
      {
          geometry_msgs::Point pt;
          pt.x = pos_pts(0, i);
          pt.y = pos_pts(1, i);
          pt.z = odom_pos_(2);
          bspline.pos_pts.push_back(pt);
          point_temp<<pt.x,pt.x,pt.x;
          //cout<<"point : "<<point_temp<<endl;
      }

      Eigen::VectorXd knots = info->position_traj_.getKnot();
      bspline.knots.reserve(knots.rows());
      for (int i = 0; i < knots.rows(); ++i)
      {
          bspline.knots.push_back(knots(i));
      }

      bspline_pub_.publish(bspline);
  }

} // namespace ego_planner
